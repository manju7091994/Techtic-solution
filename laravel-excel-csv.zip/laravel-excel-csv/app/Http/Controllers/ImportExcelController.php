<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Imports\UsersImport;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Controllers\Controller;
use DB;
class ImportExcelController extends Controller
{
    
	 function index()
    {
     $data = DB::table('tbl_product')->orderBy('ProductID', 'DESC')->get();
     return view('import_excel', compact('data'));
    }
	 function import(Request $request)
    {
     $this->validate($request, [
      'select_file'  => 'required|mimes:xls,xlsx'
     ]);
	 $path = $request->file('select_file')->getRealPath();
	 $data = Excel::load($path)->get();
	 
	  if($data->count() > 0)
     {
		foreach($data->toArray() as $key => $value)
		  {

        $insert_data[] = array(
			 'ProductName'  => $row['product_name'],
			 'Description'   => $row['description'],
			 'UniqueCode'  => $row['unique_code'],
			 'ProductCategory'   => $row['product_category']
        );
   
		  }
		if(!empty($insert_data))
		  {
		   DB::table('tbl_product')->insert($insert_data);
		  }
	 }
	  return back()->with('success', 'Excel Data Imported successfully.');
}
}
