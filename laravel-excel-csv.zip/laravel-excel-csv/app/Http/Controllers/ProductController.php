<?php

namespace App\Http\Controllers;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Maatwebsite\Excel\Concerns\WithValidation;

use DB;
use Excel;
use App\Imports\ProductImport;
class ProductController extends Controller
{
    //
	public function importForm()
	{
		$data = DB::table('tbl_product')->orderBy('ProductID', 'DESC')->get();
		 return view('import-form', compact('data'));
	}
	 function import(Request $request)
    {
		 $this->validate($request, [
      'file'  => 'required|mimes:xls,xlsx'
     ]);
		Excel::import(new ProductImport,$request->file);
		return back()->with('success', 'Excel Data Imported successfully.');
	}
	
}
 