<?php

namespace App\Imports;

use App\Models\Product;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Illuminate\Validation\Rule;
class ProductImport implements ToModel,WithHeadingRow,WithValidation
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
	 public function rules(): array
    {
    return [
        'UniqueCode'            => 'UniqueCode|unique:tbl_product,UniqueCode,NULL',
       
 
    ];
 
    }
	 public function customValidationMessages()
    {
    return [
 
                #All Email Validation for Teacher Email
              
                'UniqueCode.unique'      => 'The code has already been used',
 
 
 
 
       ];
  }
    public function model(array $row)
    {
        return new Product([
		'ProductName' => $row['product_name'],
		'Description' => $row['description'],
		'ProductID' => $row['product_id'],
		'ProductCategory' => $row['product_category'],
            //
        ]);
    }
}
