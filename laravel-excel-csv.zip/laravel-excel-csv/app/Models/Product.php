<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Maatwebsite\Excel\Concerns\WithValidation;
class Product extends Model
{
    use HasFactory;
	protected $table = "tbl_product";
	protected $fillable = ['ProductID', 'ProductName', 'Description', 'ProductCategory'];
	
	public static function getEmployee()
	{
		$records = DB::table('tbl_product')->select('ProductID', 'ProductName', 'Description', 'UniqueCode', 'ProductCategory');
		return $records;
	}
}
